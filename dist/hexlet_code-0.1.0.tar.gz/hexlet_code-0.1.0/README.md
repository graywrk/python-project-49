### Code Climate
[![Code Climate](https://codeclimate.com/github/graywrk/python-project-49.png)](https://codeclimate.com/github/graywrk/python-project-49)
### Hexlet tests and linter status:
[![Actions Status](https://github.com/graywrk/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/graywrk/python-project-49/actions)

### Asciinema
[![asciicast](https://asciinema.org/a/kPELxIAirhILy86q4ObK90Iyg.svg)](https://asciinema.org/a/kPELxIAirhILy86q4ObK90Iyg)