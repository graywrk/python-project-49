### Code Climate
[![Code Climate](https://codeclimate.com/github/graywrk/python-project-49.png)](https://codeclimate.com/github/graywrk/python-project-49)
### Hexlet tests and linter status:
[![Actions Status](https://github.com/graywrk/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/graywrk/python-project-49/actions)

### Asciinema
[![asciicast](https://asciinema.org/a/kPELxIAirhILy86q4ObK90Iyg.svg)](https://asciinema.org/a/kPELxIAirhILy86q4ObK90Iyg)
[![asciicast](https://asciinema.org/a/RGHI0or5RCtEqIg6I7AuzsGkY.svg)](https://asciinema.org/a/RGHI0or5RCtEqIg6I7AuzsGkY)
[![asciicast](https://asciinema.org/a/HucpuAjdNkeiGubXdUD3me0re.svg)](https://asciinema.org/a/HucpuAjdNkeiGubXdUD3me0re)
[![asciicast](https://asciinema.org/a/Hf6xSfs1Ye0isJOieNsdR9Ip2.svg)](https://asciinema.org/a/Hf6xSfs1Ye0isJOieNsdR9Ip2)
[![asciicast](https://asciinema.org/a/zpBHdAJHjekczOWbmbqiWveQO.svg)](https://asciinema.org/a/zpBHdAJHjekczOWbmbqiWveQO)