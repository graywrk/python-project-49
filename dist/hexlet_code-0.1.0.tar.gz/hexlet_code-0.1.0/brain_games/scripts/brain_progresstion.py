#!/usr/bin/env python3

from brain_games.games.progrestion import game


def main():
    game()


if __name__ == '__main__':
    main()